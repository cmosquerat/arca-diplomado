# Dataset de placas vehiculares — Sin etiquetar

100 imágenes de carros con placas visibles, redimensionadas a max 1280px.

## Proceso de etiquetado

1. Suban este ZIP completo a CVAT.ai como nueva *task*
2. Definan UNA sola label: `placa`
3. Etiqueten todas las imágenes (o al menos 30-40 si no tienen tiempo)
4. Exporten formato YOLO 1.1 (menú Project → Export task dataset → YOLO 1.1)
5. Suban el ZIP exportado al Drive compartido con el nombre `[apellido]_etiquetas.zip`

## Cómo etiquetar bien

- Caja **ajustada** al rectángulo de la placa (sin mucho margen)
- Si la placa está parcialmente visible, etiquetar solo lo visible
- Si hay varios carros en una imagen, etiquetar todas las placas legibles
- Si la placa es ilegible (muy lejos / borrosa), saltar esa imagen

## Origen

Subset de "License Plate Dataset" (Robert Lucian Chiriac, 2020) — licencia MIT.
